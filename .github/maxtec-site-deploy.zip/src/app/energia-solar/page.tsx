'use client';

import { useState } from 'react';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';
// import { Helmet } from 'react-helmet';

export default function EnergiasSolar() {
  return (
    <>
      <Navbar />
      
      {/* Meta tags para SEO */}
      <div className="hidden">
        {/* Comentado para evitar erro de build */}
        {/* <Helmet>
          <title>Energia Solar Residencial e Empresarial | Maxtec Inovações</title>
          <meta name="description" content="Economize até 85% na sua conta de luz com sistemas de energia solar da Maxtec. Soluções para residências, empresas e agronegócio com financiamento facilitado." />
          <meta name="keywords" content="energia solar, painel solar, sistema fotovoltaico, economia energia, energia renovável" />
          <link rel="canonical" href="https://www.maxtec.com.br/energia-solar" />
        </Helmet> */}
      </div>
      
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-overlay"></div>
        <div className="hero-image bg-gradient-to-r from-primary to-secondary"></div>
        <div className="hero-content">
          <h1 className="heading-1 text-white">Energia Solar</h1>
          <p className="subheading text-white">Reduza sua conta de energia em até 85% com nossos sistemas fotovoltaicos de alta eficiência.</p>
          <div className="flex flex-col sm:flex-row gap-4 mt-8">
            <Link href="/simulador" className="btn-accent">
              Simular Economia
            </Link>
            <Link href="/contato" className="btn-outline border-white text-white hover:bg-white hover:text-primary">
              Solicitar Orçamento
            </Link>
          </div>
        </div>
      </section>

      {/* Benefícios Section */}
      <section className="section bg-white">
        <div className="container-custom">
          <h2 className="heading-2 text-center">Por que escolher energia solar?</h2>
          <p className="subheading text-center text-gray-600">Descubra os benefícios de investir em energia solar para sua casa ou empresa</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {/* Card 1 */}
            <div className="card-feature">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-6 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-center mb-3">Economia Significativa</h3>
              <p className="text-gray-600 text-center">Reduza sua conta de energia em até 85%, com retorno do investimento em 3 a 5 anos.</p>
            </div>
            
            {/* Card 2 */}
            <div className="card-feature">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-6 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-center mb-3">Durabilidade e Garantia</h3>
              <p className="text-gray-600 text-center">Painéis solares com garantia de 25 anos e vida útil superior a 30 anos.</p>
            </div>
            
            {/* Card 3 */}
            <div className="card-feature">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-6 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-center mb-3">Valorização Imobiliária</h3>
              <p className="text-gray-600 text-center">Imóveis com energia solar são mais valorizados no mercado, com aumento de até 10% no valor.</p>
            </div>
            
            {/* Card 4 */}
            <div className="card-feature">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-6 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-center mb-3">Financiamento Facilitado</h3>
              <p className="text-gray-600 text-center">Parcelas menores que sua economia mensal, com taxas especiais e prazos de até 10 anos.</p>
            </div>
            
            {/* Card 5 */}
            <div className="card-feature">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-6 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-center mb-3">Baixa Manutenção</h3>
              <p className="text-gray-600 text-center">Sistemas fotovoltaicos requerem manutenção mínima, apenas limpeza periódica dos painéis.</p>
            </div>
            
            {/* Card 6 */}
            <div className="card-feature">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-6 mx-auto">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 11.5V14m0-2.5v-6a1.5 1.5 0 113 0m-3 6a1.5 1.5 0 00-3 0v2a7.5 7.5 0 0015 0v-5a1.5 1.5 0 00-3 0m-6-3V11m0-5.5v-1a1.5 1.5 0 013 0v1m0 0V11m0-5.5a1.5 1.5 0 013 0v3m0 0V11" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-center mb-3">Sustentabilidade</h3>
              <p className="text-gray-600 text-center">Energia limpa e renovável que reduz a emissão de CO2 e contribui para um futuro sustentável.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Como Funciona Section */}
      <section className="section bg-gray-50">
        <div className="container-custom">
          <h2 className="heading-2 text-center">Como Funciona a Energia Solar</h2>
          <p className="subheading text-center text-gray-600">Entenda o processo de geração de energia solar fotovoltaica</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-12 items-center">
            <div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center">
                  <p className="text-gray-500">Ilustração do funcionamento de um sistema fotovoltaico</p>
                  {/* Em um site real, aqui seria inserida uma imagem ou animação */}
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center mr-4 flex-shrink-0">
                  1
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">Captação da Luz Solar</h3>
                  <p className="text-gray-600">
                    Os painéis fotovoltaicos captam a luz do sol e a transformam em energia elétrica de corrente contínua (CC).
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center mr-4 flex-shrink-0">
                  2
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">Conversão da Energia</h3>
                  <p className="text-gray-600">
                    O inversor converte a energia de corrente contínua (CC) em corrente alternada (CA), compatível com a rede elétrica.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center mr-4 flex-shrink-0">
                  3
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">Distribuição</h3>
                  <p className="text-gray-600">
                    A energia gerada é utilizada para alimentar os equipamentos elétricos da casa ou empresa.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center mr-4 flex-shrink-0">
                  4
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">Excedente para a Rede</h3>
                  <p className="text-gray-600">
                    O excedente de energia é injetado na rede elétrica, gerando créditos que podem ser utilizados quando não há geração solar.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center mr-4 flex-shrink-0">
                  5
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">Monitoramento</h3>
                  <p className="text-gray-600">
                    Todo o sistema é monitorado em tempo real, permitindo acompanhar a geração e o consumo de energia.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Soluções Section */}
      <section className="section bg-white">
        <div className="container-custom">
          <h2 className="heading-2 text-center">Nossas Soluções em Energia Solar</h2>
          <p className="subheading text-center text-gray-600">Soluções personalizadas para diferentes perfis de clientes</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            {/* Solução 1 */}
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Imagem de sistema residencial</p>
                {/* Em um site real, aqui seria inserida uma imagem */}
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3">Energia Solar Residencial</h3>
                <p className="text-gray-600 mb-4">
                  Sistemas fotovoltaicos dimensionados para residências, com potência de 2 a 10 kWp, ideais para famílias que desejam reduzir a conta de luz.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-600">Economia de até 85% na conta de luz</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-600">Instalação rápida (1 a 3 dias)</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-600">Financiamento em até 120 meses</span>
                  </li>
                </ul>
                <Link href="/simulador" className="btn-primary w-full block text-center">
                  Simular Economia
                </Link>
              </div>
            </div>
            
            {/* Solução 2 */}
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Imagem de sistema empresarial</p>
                {/* Em um site real, aqui seria inserida uma imagem */}
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3">Energia Solar Empresarial</h3>
                <p className="text-gray-600 mb-4">
                  Sistemas de médio e grande porte para empresas, comércios e indústrias que buscam reduzir custos operacionais e aumentar competitividade.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-600">Redução de custos operacionais</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-600">Benefícios fiscais e depreciação acelerada</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-600">Soluções sob medida para cada negócio</span>
                  </li>
                </ul>
                <Link href="/contato" className="btn-primary w-full block text-center">
                  Solicitar Orçamento
                </Link>
              </div>
            </div>
            
            {/* Solução 3 */}
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Imagem de sistema rural</p>
                {/* Em um site real, aqui seria inserida uma imagem */}
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-3">Energia Solar Rural</h3>
                <p className="text-gray-600 mb-4">
                  Sistemas adaptados para propriedades rurais, com soluções para bombeamento de água, irrigação e eletrificação de áreas remotas.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-600">Linhas de financiamento específicas para o agro</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-600">Sistemas on-grid e off-grid</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-gray-600">Soluções para bombeamento solar</span>
                  </li>
                </ul>
                <Link href="/contato" className="btn-primary w-full block text-center">
                  Solicitar Orçamento
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projetos Section */}
      <section className="section bg-gray-50">
        <div className="container-custom">
          <h2 className="heading-2 text-center">Projetos Realizados</h2>
          <p className="subheading text-center text-gray-600">Conheça alguns dos nossos projetos de sucesso</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {/* Projeto 1 */}
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Imagem do projeto 1</p>
                {/* Em um site real, aqui seria inserida uma imagem */}
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Residência em Curitiba</h3>
                <p className="text-sm text-gray-600 mb-2">Sistema de 5 kWp | Economia de 90%</p>
                <p className="text-gray-600">
                  Sistema instalado em residência no bairro Água Verde, com 12 painéis de 450W e inversor de 5kW.
                </p>
              </div>
            </div>
            
            {/* Projeto 2 */}
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Imagem do projeto 2</p>
                {/* Em um site real, aqui seria inserida uma imagem */}
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Comércio em São José dos Pinhais</h3>
                <p className="text-sm text-gray-600 mb-2">Sistema de 15 kWp | Economia de 85%</p>
                <p className="text-gray-600">
                  Sistema instalado em supermercado, com 36 painéis de 450W e inversor de 15kW.
                </p>
              </div>
            </div>
            
            {/* Projeto 3 */}
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Imagem do projeto 3</p>
                {/* Em um site real, aqui seria inserida uma imagem */}
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Indústria em Araucária</h3>
                <p className="text-sm text-gray-600 mb-2">Sistema de 75 kWp | Economia de 80%</p>
                <p className="text-gray-600">
                  Sistema instalado em indústria metalúrgica, com 180 painéis de 450W e 3 inversores de 25kW.
                </p>
              </div>
            </div>
            
            {/* Projeto 4 */}
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Imagem do projeto 4</p>
                {/* Em um site real, aqui seria inserida uma imagem */}
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Fazenda em Campo Largo</h3>
                <p className="text-sm text-gray-600 mb-2">Sistema de 30 kWp | Economia de 95%</p>
                <p className="text-gray-600">
                  Sistema instalado em propriedade rural, com 72 painéis de 450W e 2 inversores de 15kW.
                </p>
              </div>
            </div>
            
            {/* Projeto 5 */}
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Imagem do projeto 5</p>
                {/* Em um site real, aqui seria inserida uma imagem */}
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Condomínio em Colombo</h3>
                <p className="text-sm text-gray-600 mb-2">Sistema de 50 kWp | Economia de 75%</p>
                <p className="text-gray-600">
                  Sistema instalado em condomínio residencial, com 120 painéis de 450W e 2 inversores de 25kW.
                </p>
              </div>
            </div>
            
            {/* Projeto 6 */}
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <p className="text-gray-500">Imagem do projeto 6</p>
                {/* Em um site real, aqui seria inserida uma imagem */}
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-1">Escola em Pinhais</h3>
                <p className="text-sm text-gray-600 mb-2">Sistema de 25 kWp | Economia de 85%</p>
                <p className="text-gray-600">
                  Sistema instalado em instituição de ensino, com 60 painéis de 450W e inversor de 25kW.
                </p>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-10">
            <Link href="/projetos" className="btn-primary">
              Ver Todos os Projetos
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section bg-white">
        <div className="container-custom">
          <h2 className="heading-2 text-center">Perguntas Frequentes</h2>
          <p className="subheading text-center text-gray-600">Tire suas dúvidas sobre energia solar</p>
          
          <div className="mt-12 space-y-6 max-w-3xl mx-auto">
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-bold text-lg mb-2">Quanto custa instalar energia solar?</h3>
              <p className="text-gray-600">
                O custo de instalação varia conforme o consumo de energia e o tipo de imóvel. Em média, um sistema residencial custa entre R$ 15.000 e R$ 30.000. Oferecemos condições especiais de financiamento com parcelas menores que a economia gerada, tornando o investimento viável desde o primeiro mês.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-bold text-lg mb-2">Qual o tempo de retorno do investimento?</h3>
              <p className="text-gray-600">
                O tempo de retorno do investimento (payback) varia entre 3 e 5 anos, dependendo do consumo de energia e da tarifa da distribuidora local. Considerando que os painéis têm garantia de 25 anos, o sistema continua gerando economia por mais de 20 anos após se pagar.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-bold text-lg mb-2">Preciso fazer obras na minha casa para instalar?</h3>
              <p className="text-gray-600">
                Na maioria dos casos, não são necessárias obras estruturais. A instalação é feita diretamente sobre o telhado existente, com fixadores específicos para cada tipo de telha. O sistema é conectado ao quadro de luz da residência, sem necessidade de grandes intervenções.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-bold text-lg mb-2">Como funciona o financiamento?</h3>
              <p className="text-gray-600">
                Trabalhamos com diversas linhas de financiamento, com taxas a partir de 0,99% ao mês e prazos de até 120 meses. O processo é simples e rápido, com aprovação em até 24 horas. O melhor é que as parcelas geralmente são menores que a economia gerada pelo sistema, resultando em fluxo de caixa positivo desde o primeiro mês.
              </p>
            </div>
          </div>
          
          <div className="text-center mt-10">
            <Link href="/faq" className="text-primary font-medium hover:underline">
              Ver todas as perguntas frequentes
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container-custom text-center">
          <h2 className="heading-2 text-white">Pronto para economizar com energia solar?</h2>
          <p className="subheading text-white">
            Solicite um orçamento gratuito e descubra como nossas soluções podem transformar sua casa ou empresa.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mt-8 justify-center">
            <Link href="/simulador" className="btn-accent">
              Simular Economia
            </Link>
            <Link href="/contato" className="btn-outline border-white text-white hover:bg-white hover:text-primary">
              Solicitar Orçamento
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
