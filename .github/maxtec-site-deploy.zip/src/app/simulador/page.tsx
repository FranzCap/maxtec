'use client';

import { useState } from 'react';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';

export default function Simulador() {
  const [formData, setFormData] = useState({
    consumo: '',
    tipo: 'residencial',
    cidade: '',
    nome: '',
    email: '',
    telefone: ''
  });

  const [resultado, setResultado] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const calcularEconomia = () => {
    setLoading(true);
    
    // Simulação de cálculo
    setTimeout(() => {
      const consumoMensal = parseFloat(formData.consumo) || 500;
      const valorKwh = formData.tipo === 'residencial' ? 0.85 : 0.75;
      const consumoAnual = consumoMensal * 12;
      const economiaAnual = consumoAnual * 0.85; // 85% de economia
      const valorSistema = consumoMensal * 100; // Valor aproximado do sistema
      const retornoAnos = valorSistema / economiaAnual;
      
      setResultado({
        economiaAnual: economiaAnual.toFixed(2),
        economiaPercentual: 85,
        valorSistema: valorSistema.toFixed(2),
        retornoAnos: retornoAnos.toFixed(1),
        parcelaMensal: (valorSistema / 60).toFixed(2), // Financiamento em 60x
        economiaMensal: (economiaAnual / 12).toFixed(2)
      });
      
      setLoading(false);
    }, 1500);
  };

  return (
    <>
      <Navbar />
      
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-overlay"></div>
        <div className="hero-image bg-gradient-to-r from-primary to-secondary"></div>
        <div className="hero-content">
          <h1 className="heading-1 text-white">Simulador de Economia Solar</h1>
          <p className="subheading text-white">Descubra quanto você pode economizar com energia solar e como o investimento se paga em poucos anos.</p>
        </div>
      </section>

      {/* Simulador Section */}
      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Formulário */}
            <div className="bg-gray-50 p-8 rounded-lg">
              <h2 className="heading-3 mb-6">Simule sua economia</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Valor médio da conta de luz (R$)*</label>
                  <input 
                    type="text" 
                    name="consumo"
                    value={formData.consumo}
                    onChange={handleChange}
                    placeholder="Ex: 500" 
                    className="input-custom" 
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de imóvel*</label>
                  <select 
                    name="tipo"
                    value={formData.tipo}
                    onChange={handleChange}
                    className="input-custom"
                  >
                    <option value="residencial">Residencial</option>
                    <option value="comercial">Comercial</option>
                    <option value="industrial">Industrial</option>
                    <option value="rural">Rural</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Cidade*</label>
                  <input 
                    type="text" 
                    name="cidade"
                    value={formData.cidade}
                    onChange={handleChange}
                    placeholder="Ex: Curitiba" 
                    className="input-custom" 
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Seu nome*</label>
                  <input 
                    type="text" 
                    name="nome"
                    value={formData.nome}
                    onChange={handleChange}
                    placeholder="Seu nome completo" 
                    className="input-custom" 
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">E-mail*</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="seu@email.com" 
                    className="input-custom" 
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">WhatsApp*</label>
                  <input 
                    type="tel" 
                    name="telefone"
                    value={formData.telefone}
                    onChange={handleChange}
                    placeholder="(41) 99999-9999" 
                    className="input-custom" 
                    required
                  />
                </div>
                <button 
                  type="button" 
                  className="w-full btn-primary flex items-center justify-center"
                  onClick={calcularEconomia}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Calculando...
                    </>
                  ) : "Calcular Minha Economia"}
                </button>
                <p className="text-xs text-gray-500 mt-2">
                  Ao enviar, você concorda com nossa política de privacidade e aceita receber comunicações da Maxtec Inovações.
                </p>
              </div>
            </div>
            
            {/* Resultado ou Informações */}
            {resultado ? (
              <div className="bg-white border border-green-200 p-8 rounded-lg shadow-lg">
                <div className="bg-green-50 p-4 rounded-md mb-6">
                  <h3 className="text-xl font-bold text-green-800 mb-2">Resultado da Simulação</h3>
                  <p className="text-green-700">
                    Com base nas informações fornecidas, veja quanto você pode economizar com energia solar:
                  </p>
                </div>
                
                <div className="space-y-6">
                  <div className="border-b pb-4">
                    <p className="text-gray-600">Economia mensal estimada:</p>
                    <p className="text-3xl font-bold text-primary">R$ {resultado.economiaMensal}</p>
                  </div>
                  
                  <div className="border-b pb-4">
                    <p className="text-gray-600">Economia anual estimada:</p>
                    <p className="text-2xl font-bold text-primary">R$ {resultado.economiaAnual}</p>
                  </div>
                  
                  <div className="border-b pb-4">
                    <p className="text-gray-600">Redução na conta de energia:</p>
                    <p className="text-2xl font-bold text-primary">{resultado.economiaPercentual}%</p>
                  </div>
                  
                  <div className="border-b pb-4">
                    <p className="text-gray-600">Investimento estimado:</p>
                    <p className="text-2xl font-bold text-primary">R$ {resultado.valorSistema}</p>
                  </div>
                  
                  <div className="border-b pb-4">
                    <p className="text-gray-600">Tempo de retorno do investimento:</p>
                    <p className="text-2xl font-bold text-primary">{resultado.retornoAnos} anos</p>
                  </div>
                  
                  <div className="bg-blue-50 p-4 rounded-md">
                    <h4 className="font-bold text-blue-800 mb-2">Financiamento disponível</h4>
                    <p className="text-blue-700 mb-2">
                      Parcelas a partir de <span className="font-bold">R$ {resultado.parcelaMensal}/mês</span>
                    </p>
                    <p className="text-blue-700 text-sm">
                      *Valor menor que sua economia mensal! Você economiza desde o primeiro mês.
                    </p>
                  </div>
                  
                  <div className="mt-8">
                    <Link href="/contato" className="btn-primary w-full block text-center">
                      Quero Economizar Agora
                    </Link>
                    <button 
                      onClick={() => setResultado(null)} 
                      className="mt-4 text-primary hover:underline w-full text-center"
                    >
                      Fazer nova simulação
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <h2 className="heading-3 mb-6">Por que escolher energia solar?</h2>
                
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-4 flex-shrink-0">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Economia de até 85%</h3>
                      <p className="text-gray-600">
                        Reduza drasticamente sua conta de energia elétrica desde o primeiro mês, mesmo com financiamento.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-4 flex-shrink-0">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Garantia de 25 anos</h3>
                      <p className="text-gray-600">
                        Nossos painéis solares têm garantia de 25 anos de geração, com manutenção mínima.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-4 flex-shrink-0">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Retorno rápido</h3>
                      <p className="text-gray-600">
                        O investimento se paga em 3 a 5 anos, e o sistema dura mais de 25 anos.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-4 flex-shrink-0">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Valorização do imóvel</h3>
                      <p className="text-gray-600">
                        Imóveis com energia solar são mais valorizados no mercado imobiliário.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-4 flex-shrink-0">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Financiamento facilitado</h3>
                      <p className="text-gray-600">
                        Parcelas menores que sua economia mensal, com taxas especiais.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section bg-gray-50">
        <div className="container-custom">
          <h2 className="heading-2 text-center">Perguntas Frequentes</h2>
          <p className="subheading text-center text-gray-600">Tire suas dúvidas sobre energia solar</p>
          
          <div className="mt-12 space-y-6 max-w-3xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-bold text-lg mb-2">Como funciona a energia solar fotovoltaica?</h3>
              <p className="text-gray-600">
                A energia solar fotovoltaica funciona através da conversão direta da luz do sol em eletricidade. Os painéis solares captam a luz solar e a transformam em energia elétrica, que é convertida para o padrão da rede elétrica pelo inversor. O sistema é conectado à rede da distribuidora, permitindo compensar o consumo.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-bold text-lg mb-2">Quanto custa instalar energia solar?</h3>
              <p className="text-gray-600">
                O custo de instalação varia conforme o consumo de energia e o tipo de imóvel. Em média, um sistema residencial custa entre R$ 15.000 e R$ 30.000. Oferecemos condições especiais de financiamento com parcelas menores que a economia gerada, tornando o investimento viável desde o primeiro mês.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-bold text-lg mb-2">Quanto tempo dura um sistema de energia solar?</h3>
              <p className="text-gray-600">
                Os painéis solares têm garantia de 25 anos de geração, mas podem durar mais de 30 anos. Os inversores geralmente têm garantia de 5 a 10 anos. A manutenção é simples, consistindo basicamente na limpeza periódica dos painéis.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-bold text-lg mb-2">Funciona em dias nublados ou chuvosos?</h3>
              <p className="text-gray-600">
                Sim, os painéis solares continuam gerando energia mesmo em dias nublados ou chuvosos, embora com eficiência reduzida. O dimensionamento do sistema leva em conta as condições climáticas da região ao longo do ano, garantindo que a geração anual atenda às necessidades do cliente.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-bold text-lg mb-2">Preciso de baterias para armazenar energia?</h3>
              <p className="text-gray-600">
                Não necessariamente. O sistema mais comum é o on-grid (conectado à rede), que utiliza a rede elétrica como "bateria virtual". A energia excedente gerada durante o dia é injetada na rede, gerando créditos que podem ser utilizados à noite ou em dias de baixa geração. Sistemas com baterias (off-grid ou híbridos) são recomendados apenas para locais sem acesso à rede elétrica ou para quem deseja independência energética total.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container-custom text-center">
          <h2 className="heading-2 text-white">Pronto para economizar?</h2>
          <p className="subheading text-white">
            Entre em contato conosco hoje mesmo e descubra como nossas soluções podem transformar sua casa ou empresa.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mt-8 justify-center">
            <Link href="/contato" className="btn-accent">
              Solicitar Orçamento
            </Link>
            <a href="https://wa.me/5541999999999" target="_blank" rel="noopener noreferrer" className="btn-outline border-white text-white hover:bg-white hover:text-primary">
              Falar no WhatsApp
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
