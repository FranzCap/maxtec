'use client';

import { useEffect } from 'react';

export default function SiteMap() {
  return (
    <div className="container-custom py-12">
      <h1 className="heading-2 mb-8">Mapa do Site</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h2 className="text-xl font-bold mb-4">Páginas Principais</h2>
          <ul className="space-y-2">
            <li>
              <a href="/" className="text-primary hover:underline">Página Inicial</a>
            </li>
            <li>
              <a href="/energia-solar" className="text-primary hover:underline">Energia Solar</a>
              <ul className="pl-4 mt-2 space-y-2">
                <li>
                  <a href="/energia-solar-residencial" className="text-gray-600 hover:underline">Energia Solar Residencial</a>
                </li>
                <li>
                  <a href="/energia-solar-empresarial" className="text-gray-600 hover:underline">Energia Solar Empresarial</a>
                </li>
                <li>
                  <a href="/energia-solar-rural" className="text-gray-600 hover:underline">Energia Solar Rural</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="/aquecimento" className="text-primary hover:underline">Aquecimento Solar</a>
            </li>
            <li>
              <a href="/piscinas" className="text-primary hover:underline">Piscinas Sustentáveis</a>
            </li>
            <li>
              <a href="/sobre" className="text-primary hover:underline">Sobre Nós</a>
            </li>
            <li>
              <a href="/contato" className="text-primary hover:underline">Contato</a>
            </li>
          </ul>
        </div>
        
        <div>
          <h2 className="text-xl font-bold mb-4">Ferramentas</h2>
          <ul className="space-y-2">
            <li>
              <a href="/simulador" className="text-primary hover:underline">Simulador de Economia</a>
            </li>
            <li>
              <a href="/calculadora-dimensionamento" className="text-primary hover:underline">Calculadora de Dimensionamento</a>
            </li>
            <li>
              <a href="/comparativo" className="text-primary hover:underline">Comparativo Energia Convencional vs. Solar</a>
            </li>
          </ul>
          
          <h2 className="text-xl font-bold mt-8 mb-4">Recursos</h2>
          <ul className="space-y-2">
            <li>
              <a href="/blog" className="text-primary hover:underline">Blog</a>
            </li>
            <li>
              <a href="/faq" className="text-primary hover:underline">Perguntas Frequentes</a>
            </li>
            <li>
              <a href="/glossario" className="text-primary hover:underline">Glossário</a>
            </li>
            <li>
              <a href="/downloads" className="text-primary hover:underline">Downloads</a>
            </li>
          </ul>
        </div>
        
        <div>
          <h2 className="text-xl font-bold mb-4">Institucional</h2>
          <ul className="space-y-2">
            <li>
              <a href="/projetos" className="text-primary hover:underline">Projetos Realizados</a>
            </li>
            <li>
              <a href="/depoimentos" className="text-primary hover:underline">Depoimentos</a>
            </li>
            <li>
              <a href="/parceiros" className="text-primary hover:underline">Parceiros</a>
            </li>
            <li>
              <a href="/trabalhe-conosco" className="text-primary hover:underline">Trabalhe Conosco</a>
            </li>
            <li>
              <a href="/politica-privacidade" className="text-primary hover:underline">Política de Privacidade</a>
            </li>
            <li>
              <a href="/termos-uso" className="text-primary hover:underline">Termos de Uso</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
