'use client';

import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';
import Head from 'next/head';

export default function SEOComponent() {
  return (
    <>
      <Head>
        <title>Maxtec Inovações | Energia Solar, Aquecimento e Piscinas</title>
        <meta name="description" content="Soluções completas em energia solar, aquecimento solar e piscinas sustentáveis. Economize até 85% na sua conta de energia com nossos sistemas fotovoltaicos." />
        <meta name="keywords" content="energia solar, aquecimento solar, piscinas sustentáveis, painéis solares, economia de energia, Curitiba, Paraná" />
        <meta name="robots" content="index, follow" />
        <meta name="author" content="Maxtec Inovações" />
        <meta property="og:title" content="Maxtec Inovações | Energia Solar, Aquecimento e Piscinas" />
        <meta property="og:description" content="Soluções completas em energia solar, aquecimento solar e piscinas sustentáveis. Economize até 85% na sua conta de energia." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.maxtec.com.br/" />
        <meta property="og:image" content="https://www.maxtec.com.br/og-image.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Maxtec Inovações | Energia Solar, Aquecimento e Piscinas" />
        <meta name="twitter:description" content="Soluções completas em energia solar, aquecimento solar e piscinas sustentáveis." />
        <meta name="twitter:image" content="https://www.maxtec.com.br/twitter-image.jpg" />
        <link rel="canonical" href="https://www.maxtec.com.br/" />
      </Head>
    </>
  );
}
