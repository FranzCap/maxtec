'use client';

import { useEffect } from 'react';
import Script from 'next/script';

export default function SEOOptimization() {
  useEffect(() => {
    // Adicionar schema.org JSON-LD para organização
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.innerHTML = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Organization',
      'name': 'Maxtec Inovações',
      'url': 'https://www.maxtec.com.br',
      'logo': 'https://www.maxtec.com.br/logo.png',
      'description': 'Soluções completas em energia solar, aquecimento solar e piscinas sustentáveis.',
      'address': {
        '@type': 'PostalAddress',
        'streetAddress': 'Av. República Argentina, 1228',
        'addressLocality': 'Curitiba',
        'addressRegion': 'PR',
        'postalCode': '80620-010',
        'addressCountry': 'BR'
      },
      'contactPoint': {
        '@type': 'ContactPoint',
        'telephone': '+554133334444',
        'contactType': 'customer service',
        'availableLanguage': 'Portuguese'
      },
      'sameAs': [
        'https://www.facebook.com/maxtec',
        'https://www.instagram.com/maxtec',
        'https://www.linkedin.com/company/maxtec'
      ]
    });
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  return (
    <>
      {/* Google Analytics (seria substituído por um ID real) */}
      <Script
        strategy="afterInteractive"
        src={`https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX`}
      />
      <Script
        id="google-analytics"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-XXXXXXXXXX');
          `,
        }}
      />
    </>
  );
}
