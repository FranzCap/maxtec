'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Menu, X } from 'lucide-react';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container-custom py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold text-primary">Maxtec</span>
            <span className="text-2xl font-bold text-accent">Inovações</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="nav-link font-medium">
              Home
            </Link>
            <Link href="/energia-solar" className="nav-link font-medium">
              Energia Solar
            </Link>
            <Link href="/aquecimento" className="nav-link font-medium">
              Aquecimento
            </Link>
            <Link href="/piscinas" className="nav-link font-medium">
              Piscinas
            </Link>
            <Link href="/sobre" className="nav-link font-medium">
              Sobre Nós
            </Link>
            <Link href="/contato" className="nav-link font-medium">
              Contato
            </Link>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:block">
            <Link href="/simulador" className="btn-primary">
              Simular Economia
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-4 space-y-2">
            <Link
              href="/"
              className="nav-link-mobile"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/energia-solar"
              className="nav-link-mobile"
              onClick={() => setIsMenuOpen(false)}
            >
              Energia Solar
            </Link>
            <Link
              href="/aquecimento"
              className="nav-link-mobile"
              onClick={() => setIsMenuOpen(false)}
            >
              Aquecimento
            </Link>
            <Link
              href="/piscinas"
              className="nav-link-mobile"
              onClick={() => setIsMenuOpen(false)}
            >
              Piscinas
            </Link>
            <Link
              href="/sobre"
              className="nav-link-mobile"
              onClick={() => setIsMenuOpen(false)}
            >
              Sobre Nós
            </Link>
            <Link
              href="/contato"
              className="nav-link-mobile"
              onClick={() => setIsMenuOpen(false)}
            >
              Contato
            </Link>
            <Link
              href="/simulador"
              className="block py-2 px-4 bg-primary text-white rounded-md"
              onClick={() => setIsMenuOpen(false)}
            >
              Simular Economia
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
}
